<?php
/* Smarty version 3.1.30, created on 2016-10-14 11:47:43
  from "/cshome/under/u103/tch103u/WWW/smarty/templates/index.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5800c5df989cd0_30181483',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b79f788eddbe3fedc8d9f9fa2a84ec4120752a3a' => 
    array (
      0 => '/cshome/under/u103/tch103u/WWW/smarty/templates/index.tpl',
      1 => 1476445505,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5800c5df989cd0_30181483 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
<body>
<?php echo $_smarty_tpl->tpl_vars['hello']->value;?>

</body>
</html>
<?php }
}
